import requests, json, sys

target_subsystem=sys.argv[1]
source_id=sys.argv[2]

rest_service_url="http://eric-esoa-rest-service:8080/rest-service/v1/run/" + target_subsystem + "/" + target_subsystem + "/source"

data={"inputs": {"id": source_id}}
response = requests.post(rest_service_url, json=data)
response.raise_for_status()
print(response.text)